import 'package:flutter/material.dart';


class Plant {
  Plant({
    required this.name,
    required this.species,
    required this.waterIntervalDays,
    required this.heightCm,
    required this.isIndoor,
  });

  final String name; // String
  final String species; // String
  final int waterIntervalDays; // int
  final double heightCm; // double
  final bool isIndoor; // bool
}

// Shifa Athallah Muzakki_202432063Z
final Plant monstera = Plant(
  name: 'Monstera Deliciosa',
  species: 'Araceae, tanaman rambat tropis dengan daun berlubang',
  waterIntervalDays: 7,
  heightCm: 85.5,
  isIndoor: true,
);


const String appTitle = 'Katalog Tanaman Hias';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: appTitle,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6B8E23),
        ),
      ),
      home: const HomePage(),
    );
  }
}
//Shifa Athallah Muzakki_202432063

//Shifa Athallah Muzakki_202432063
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text(appTitle),
        backgroundColor: colors.primaryContainer,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Tanaman Pilihan Hari Ini',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),

              PlantSummaryCard(plant: monstera),
              const SizedBox(height: 16),

              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: colors.secondaryContainer,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: colors.primary),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.lightbulb_outline, color: colors.primary),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'Tips: letakkan di dekat jendela dengan cahaya '
                        'terang tidak langsung, dan siram saat tanah '
                        'bagian atas mulai kering.',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          '${monstera.name} ditambahkan ke daftar rawat.',
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.add),
                  label: const Text('Tambah ke Daftar Rawat'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PlantSummaryCard extends StatelessWidget {
  const PlantSummaryCard({super.key, required this.plant});

  final Plant plant;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.local_florist, size: 40, color: colors.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        plant.name,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        plant.species,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            // Wrap otomatis pindah baris jika layar sempit.
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                InfoChip(
                  icon: Icons.water_drop,
                  label: 'Siram tiap ${plant.waterIntervalDays} hari',
                ),
                InfoChip(
                  icon: Icons.height,
                  label: '${plant.heightCm} cm',
                ),
                InfoChip(
                  icon: plant.isIndoor ? Icons.home : Icons.park,
                  label: plant.isIndoor ? 'Dalam ruangan' : 'Luar ruangan',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// Shifa Athallah Muzakki_202432063
class InfoChip extends StatelessWidget {
  const InfoChip({super.key, required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: colors.primaryContainer,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: colors.onPrimaryContainer),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              label,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: colors.onPrimaryContainer),
            ),
          ),
        ],
      ),
    );
  }
}
//Shifa Athallah Muzakki_202432063